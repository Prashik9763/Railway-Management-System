﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace railway
{
    public partial class TravelMaster : Form
    {
        public TravelMaster()
        {
            InitializeComponent();
            TravellDGV.ReadOnly = true;
            TravellDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Attach event handler for cell click
            changestatus();
            TravellDGV.CellClick += TravellDGV_CellContentClick;
            populate();
            FillTCode();
        }

        private SqlConnection Con = new SqlConnection(@"Data Source=LENOVO\SQLEXPRESS; Initial Catalog=Railway; Integrated Security=True; Encrypt=True; TrustServerCertificate=True");

        private void populate()
        {
            Con.Open();
            string query = "Select * from TRAVELTBL";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            var ds = new DataSet();
            sda.Fill(ds);
            TravellDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void FillTCode()
        {
            string TrStatus = "Available";
            Con.Open();
            SqlCommand cmd = new SqlCommand("select TrainID from TRAINTBL where TrainStatus='" + TrStatus + "'", Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TrainID", typeof(int));
            dt.Load(rdr);
            TrainCode.ValueMember = "TrainID";
            TrainCode.DataSource = dt;
            Con.Close();

        }


        private void TravelMaster_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            MainForm Main = new MainForm();
            Main.Show();
            this.Hide();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (TravelCostTb.Text == "" || TrainCode.SelectedIndex == -1 || SourceCb.SelectedIndex == -1 || DestinationCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
                return;
            }
            else
            {
                try
                {
                    Con.Open();
                    // Adjust column names as per your database table
                    string Query = "INSERT INTO TRAVELTBL ([TravDate], Train, Src, Dest, Cost) VALUES (@TravDate, @Train, @Src, @Dest, @Cost)";
                    using (SqlCommand cmd = new SqlCommand(Query, Con))
                    {
                        cmd.Parameters.AddWithValue("@TravDate", TravelDate.Value);
                        cmd.Parameters.AddWithValue("@Train", TrainCode.SelectedValue); // Assuming you want the selected value not index
                        cmd.Parameters.AddWithValue("@Src", SourceCb.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@Dest", DestinationCb.SelectedItem.ToString());
                        cmd.Parameters.AddWithValue("@Cost", Convert.ToDecimal(TravelCostTb.Text));

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Travel added successfully");
                    }
                    Con.Close();
                    populate();
                    changestatus();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void reset()
        {
            SourceCb.SelectedIndex = -1;
            DestinationCb.SelectedIndex = -1;
            TrainCode.SelectedIndex = -1;
            TravelCostTb.Text = "";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (SourceCb.SelectedIndex == -1 || DestinationCb.SelectedIndex == -1 || TravelCostTb.Text == "")
            {
                MessageBox.Show("Missing Info: ");
                return; // Prevent further execution if information is missing
            }
            else
            {
                try
                {
                    Con.Open();
                    string Query = "UPDATE TRAVELTBL SET TravDate=@TravDate, Train=@Train, Src=@Src, Dest=@Dest, Cost=@Cost WHERE TravCode=@TravCode;";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.Parameters.AddWithValue("@TravDate", TravelDate.Text); // Assuming TravelDate.Text gives correct SQL date format
                    cmd.Parameters.AddWithValue("@Train", TrainCode.SelectedValue);
                    cmd.Parameters.AddWithValue("@Src", SourceCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Dest", DestinationCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Cost", TravelCostTb.Text);
                    cmd.Parameters.AddWithValue("@TravCode", key);  // Ensure 'key' has the correct value

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Travel Updated successfully");
                    Con.Close();
                    populate();
                    reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }


        private void changestatus()
        {
            if (TrainCode.SelectedValue == null)
            {
                MessageBox.Show("No train selected.");
                return;
            }

            string TrStatus = "Busy";
            try
            {
                Con.Open();
                string Query = "UPDATE TRAINTBL SET TrainStatus=@TrainStatus WHERE TrainId=@TrainId;";
                using (SqlCommand cmd = new SqlCommand(Query, Con))
                {
                    cmd.Parameters.AddWithValue("@TrainStatus", TrStatus);
                    cmd.Parameters.AddWithValue("@TrainId", TrainCode.SelectedValue.ToString());

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Train Updated Successfully");
                }
                Con.Close();
                populate();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }


        int key = 0;
        private void TravellDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ignore clicks on column headers
            if (e.RowIndex == -1)
            {
                return;
            }

            // Get the current row based on the clicked cell
            DataGridViewRow row = TravellDGV.Rows[e.RowIndex];

            // Update controls in the workspace
            TravelDate.Text = Convert.ToString(row.Cells["TravDate"].Value); // Replace "TravelDateColumn" with your actual column name
            TrainCode.SelectedValue = Convert.ToString(row.Cells["Train"].Value); // Replace "TrainCodeColumn" with your actual column name
            SourceCb.SelectedItem = Convert.ToString(row.Cells["Src"].Value); // Replace "SourceColumn" with your actual column name
            DestinationCb.SelectedItem = Convert.ToString(row.Cells["Dest"].Value); // Replace "DestinationColumn" with your actual column name
            TravelCostTb.Text = Convert.ToString(row.Cells["Cost"].Value); // Replace "CostColumn" with your actual column name

            // Assuming 'key' is a class member that needs to be set
            int.TryParse(Convert.ToString(row.Cells["TravCode"].Value), out var key); // Parsing key safely
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Select the to be deleted: ");
            }
            else
            {
                try
                {

                    Con.Open();
                    string Query = "Delete from PASSENGERTBL where PId=" + key + "";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Passenger Deleted succcessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
                finally
                {
                    Con.Close();
                    populate(); // Refresh data grid view
                    reset();    // Reset all input controls
                }
            }
        }
    }
}



