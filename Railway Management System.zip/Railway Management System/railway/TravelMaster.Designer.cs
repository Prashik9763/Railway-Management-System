﻿using System.Windows.Forms;

namespace railway
{
    partial class TravelMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TravelCostTb = new System.Windows.Forms.TextBox();
            this.DestinationCb = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.TravellDGV = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.SourceCb = new System.Windows.Forms.ComboBox();
            this.TrainCode = new System.Windows.Forms.ComboBox();
            this.TravelDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TravellDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // TravelCostTb
            // 
            this.TravelCostTb.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TravelCostTb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TravelCostTb.Location = new System.Drawing.Point(822, 101);
            this.TravelCostTb.Name = "TravelCostTb";
            this.TravelCostTb.Size = new System.Drawing.Size(209, 27);
            this.TravelCostTb.TabIndex = 49;
            // 
            // DestinationCb
            // 
            this.DestinationCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DestinationCb.FormattingEnabled = true;
            this.DestinationCb.Items.AddRange(new object[] {
            "Mumbai",
            "Delhi",
            "Kolkata",
            "Bangalore",
            "Chennai",
            "Hyderabad",
            "Pune",
            "Ahmedabad",
            "Jaipur",
            "Surat",
            "Lucknow",
            "Kanpur",
            "Nagpur",
            "Indore",
            "Bhopal",
            "Ludhiana",
            "Patna",
            "Vishakhapatnam",
            "Kochi",
            "Coimbatore",
            "",
            "",
            "",
            ""});
            this.DestinationCb.Location = new System.Drawing.Point(661, 101);
            this.DestinationCb.Name = "DestinationCb";
            this.DestinationCb.Size = new System.Drawing.Size(137, 28);
            this.DestinationCb.TabIndex = 48;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Magenta;
            this.button4.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.Location = new System.Drawing.Point(468, 169);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(114, 43);
            this.button4.TabIndex = 45;
            this.button4.Text = "EDIT";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // TravellDGV
            // 
            this.TravellDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TravellDGV.Location = new System.Drawing.Point(60, 252);
            this.TravellDGV.Name = "TravellDGV";
            this.TravellDGV.RowHeadersWidth = 51;
            this.TravellDGV.RowTemplate.Height = 24;
            this.TravellDGV.Size = new System.Drawing.Size(939, 239);
            this.TravellDGV.TabIndex = 44;
            this.TravellDGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TravellDGV_CellContentClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(465, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 16);
            this.label5.TabIndex = 50;
            this.label5.Text = "Travel Master";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button6.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.Location = new System.Drawing.Point(468, 515);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(114, 43);
            this.button6.TabIndex = 51;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button7.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button7.Location = new System.Drawing.Point(182, 169);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(114, 43);
            this.button7.TabIndex = 52;
            this.button7.Text = "ADD";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button9.Font = new System.Drawing.Font("Leelawadee UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button9.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button9.Location = new System.Drawing.Point(752, 169);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(114, 43);
            this.button9.TabIndex = 54;
            this.button9.Text = "Reset";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // SourceCb
            // 
            this.SourceCb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SourceCb.FormattingEnabled = true;
            this.SourceCb.Items.AddRange(new object[] {
            "Mumbai",
            "Delhi",
            "Kolkata",
            "Bangalore",
            "Chennai",
            "Hyderabad",
            "Pune",
            "Ahmedabad",
            "Jaipur",
            "Surat",
            "Lucknow",
            "Kanpur",
            "Nagpur",
            "Indore",
            "Bhopal",
            "Ludhiana",
            "Patna",
            "Vishakhapatnam",
            "Kochi",
            "Coimbatore",
            "",
            "",
            "",
            ""});
            this.SourceCb.Location = new System.Drawing.Point(468, 101);
            this.SourceCb.Name = "SourceCb";
            this.SourceCb.Size = new System.Drawing.Size(137, 28);
            this.SourceCb.TabIndex = 56;
            // 
            // TrainCode
            // 
            this.TrainCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrainCode.FormattingEnabled = true;
            this.TrainCode.Items.AddRange(new object[] {
            "310",
            "311",
            "312",
            "315",
            "317",
            "320"});
            this.TrainCode.Location = new System.Drawing.Point(257, 100);
            this.TrainCode.Name = "TrainCode";
            this.TrainCode.Size = new System.Drawing.Size(137, 28);
            this.TrainCode.TabIndex = 57;
            // 
            // TravelDate
            // 
            this.TravelDate.Location = new System.Drawing.Point(31, 100);
            this.TravelDate.Name = "TravelDate";
            this.TravelDate.Size = new System.Drawing.Size(200, 22);
            this.TravelDate.TabIndex = 58;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(492, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 16);
            this.label10.TabIndex = 59;
            this.label10.Text = "Source";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(281, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 16);
            this.label11.TabIndex = 60;
            this.label11.Text = "Train Code";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(57, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 16);
            this.label12.TabIndex = 61;
            this.label12.Text = "Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(683, 54);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 16);
            this.label13.TabIndex = 62;
            this.label13.Text = "Destination";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(880, 54);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 16);
            this.label14.TabIndex = 63;
            this.label14.Text = "Travel Cost";
            // 
            // TravelMaster
            // 
            this.ClientSize = new System.Drawing.Size(1045, 585);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.TravelDate);
            this.Controls.Add(this.TrainCode);
            this.Controls.Add(this.SourceCb);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TravelCostTb);
            this.Controls.Add(this.DestinationCb);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.TravellDGV);
            this.Name = "TravelMaster";
            ((System.ComponentModel.ISupportInitialize)(this.TravellDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TCost;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox DestCb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker TravDate;
        private System.Windows.Forms.ComboBox SrcCb;
        private System.Windows.Forms.ComboBox TCode;
        private System.Windows.Forms.DataGridView TravelDGV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox TravelCostTb;
        private System.Windows.Forms.ComboBox DestinationCb;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView TravellDGV;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;

        public TravelMaster(Button button7)
        {
            this.TravelDGV = new System.Windows.Forms.DataGridView();

            this.button7 = button7;
        }
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ComboBox SourceCb;
        private System.Windows.Forms.ComboBox TrainCode;
        private System.Windows.Forms.DateTimePicker TravelDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}