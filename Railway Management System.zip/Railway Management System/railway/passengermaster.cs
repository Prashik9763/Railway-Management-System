﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace railway
{
    public partial class passengermaster : Form
    {
        public passengermaster()
        {
            InitializeComponent();
            populate();
        }


        private SqlConnection Con = new SqlConnection(@"Data Source=LENOVO\SQLEXPRESS; Initial Catalog=Railway; Integrated Security=True; Encrypt=True; TrustServerCertificate=True");

        private void populate()
        {
            Con.Open();
            string query = "Select * from PASSENGERTBL";
            SqlDataAdapter adapter = new SqlDataAdapter(query, Con);
            var ds = new DataSet();
            adapter.Fill(ds);  // Fixed from sda.Fill(ds) to adapter.Fill(ds)
            PassengerDGV.DataSource = ds.Tables[0];
            Con.Close();  // Remember to close your connection
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string Gender = "";
            if (PnameTb.Text == "" || PphoneTb.Text == "" || PaddressTb.Text == "")
            {
                MessageBox.Show("Missing Info: ");
                return; // Prevent further execution if information is missing
            }

            if (Malerd.Checked)
            {
                Gender = "Male";
            }
            else if (FemaleRd.Checked)
            {
                Gender = "Female";
            }

            try
            {
                Con.Open();
                // Correcting SQL Query Syntax
                string Query = "insert into PASSENGERTBL values('" + PnameTb.Text + "','" + PaddressTb.Text + "','" + Gender + "','" + NatCb.SelectedItem.ToString() + "','"+PphoneTb.Text + "')"; 
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Passenger added successfully");
                Con.Close();
                populate(); // Uncomment this if you have a populate method that needs to be called here
                reset();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        private void reset()
        {
            PnameTb.Text = "";
            PaddressTb.Text = "";
            PphoneTb.Text = "";
            Malerd.Checked = false;
            FemaleRd.Checked = false;
            NatCb.SelectedIndex = -1;
            key =0;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            reset();    
        }
        int key = 0;

        private void PassengerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Check if the clicked row index is within the valid range
            if (e.RowIndex >= 0 && e.RowIndex < PassengerDGV.Rows.Count)
            {
                DataGridViewRow row = PassengerDGV.Rows[e.RowIndex];

                // Safely retrieve values from cells, ensuring the cell has a value
                PnameTb.Text = row.Cells[1].Value?.ToString() ?? "";
                PaddressTb.Text = row.Cells[2].Value?.ToString() ?? "";
                NatCb.SelectedItem = row.Cells[4].Value?.ToString() ?? "";
                PphoneTb.Text = row.Cells[5].Value?.ToString() ?? "";

                // Use the primary key value from the correct cell, assuming it is in cell[0]
                if (PnameTb.Text == "")
                {
                    key = 0;
                }
                else
                {
                    // Assuming the key is stored in the first cell (index 0)
                    key = Convert.ToInt32(row.Cells[0].Value?.ToString() ?? "0");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (key == 0)
            {
                MessageBox.Show("Select the passenger to be deleted: ");
            }
            else
            {
                try
                {

                    Con.Open();
                    string Query = "Delete from PASSENGERTBL where PId=" + key + "";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Passenger Deleted succcessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Gender = "";
            if (PnameTb.Text == "" || PphoneTb.Text == "" || PaddressTb.Text == "")
            {
                MessageBox.Show("Missing Info: ");
                return; // Prevent further execution if information is missing
            }

            if (Malerd.Checked)
            {
                Gender = "Male";
            }
            else if (FemaleRd.Checked)
            {
                Gender = "Female";
            }

            try
            {
                Con.Open();
              
                string Query = "UPDATE PASSENGERTBL SET Pname='" + PnameTb.Text + "', PAdd='" + PaddressTb.Text + "', PGender='" + Gender + "',PNat='"+NatCb.SelectedItem.ToString()+"',PPhone='"+PphoneTb.Text+"' WHERE PID=" + key + ";";
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Passenger updated successfully");
                Con.Close();
                populate(); // Uncomment this if you have a populate method that needs to be called here
                reset();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainForm Main = new MainForm();
            Main.Show();
            this.Hide();
        }
    }
}
