﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace railway
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            cancellation Cancel= new cancellation();
            Cancel.Show();
            this.Hide(); 
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Reservation Res = new Reservation();
            Res.Show();
            this.Hide(); 
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            TravelMaster Tr = new TravelMaster();
            Tr.Show();
            this.Hide(); 
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            passengermaster ps = new passengermaster();
            ps.Show();
            this.Hide(); 
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            TrainMaster Tm = new TrainMaster();
            Tm.Show();
            this.Hide(); 
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            login login = new login();
            login.Show();
            this.Hide(); 
        }
    }
}
