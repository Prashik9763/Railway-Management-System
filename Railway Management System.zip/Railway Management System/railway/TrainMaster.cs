﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace railway
{
    public partial class TrainMaster : Form
    {
        public TrainMaster()
        {
            InitializeComponent();
            populate();
        }
        private SqlConnection Con = new SqlConnection(@"Data Source=LENOVO\SQLEXPRESS;Initial Catalog=Railway;Integrated Security=True");
        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click_1(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        int key = 0;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Check if the clicked row index is within the valid range
            if (e.RowIndex >= 0 && e.RowIndex < TrainDGV.Rows.Count)
            {
                DataGridViewRow row = TrainDGV.Rows[e.RowIndex];

                // Safely retrieve values from cells, ensuring the cell has a value
                TrNameTb.Text = row.Cells[1].Value?.ToString() ?? "";
                TrainCapTb.Text = row.Cells[2].Value?.ToString() ?? "";

                // Use the primary key value from the correct cell, assuming it is in cell[0]
                if (TrNameTb.Text == "")
                {
                    key = 0;
                }
                else
                {
                    // Assuming the key is stored in the first cell (index 0)
                    key = Convert.ToInt32(row.Cells[0].Value?.ToString() ?? "0");
                }
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string TrStatus = "";
            if (TrNameTb.Text == "" || TrainCapTb.Text == "")
            {
                MessageBox.Show("Missing Info: ");
                return; // Add return to prevent execution if fields are empty
            }

            if (BusyRd.Checked)
            {
                TrStatus = "Busy";
            }
            else if (FreeRd.Checked)
            {
                TrStatus = "Available";
            }

            try
            {
                Con.Open();
                // Correcting SQL Query Syntax
                string Query = "UPDATE TRAINTBL SET TrainaName='" + TrNameTb.Text + "', TrainCap='" + TrainCapTb.Text + "', TrainStatus='" + TrStatus + "' WHERE TrainId=" + key + ";";
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Train Updated Successfully");
                Con.Close();
                populate();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }



        private void reset()
        {
            TrNameTb.Text = "";
            TrainCapTb.Text = "";
            BusyRd.Checked= false;
            key = 0;
            FreeRd.Checked= false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(key==0)
            {
                MessageBox.Show("Select the train to be deleted: ");
            }
            else
            {
                try
                {

                    Con.Open();
                    string Query = "Delete from TRAINTBL where trainId="+key+"";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Train Deleted succcessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        private void populate()
        {
            Con.Open();
            string query = "Select * from TRAINTBL";
            SqlDataAdapter adapter = new SqlDataAdapter(query, Con);
            var ds = new DataSet();
            adapter.Fill(ds);  // Fixed from sda.Fill(ds) to adapter.Fill(ds)
            TrainDGV.DataSource = ds.Tables[0];
            Con.Close();  // Remember to close your connection
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string TrStatus="";
            if(TrNameTb.Text== "" || TrainCapTb.Text=="")
            {
                MessageBox.Show("Missing Info: ");

            }   
            else
            {
                if (BusyRd.Checked == true)
                {
                    TrStatus = "Busy";
                }else if (FreeRd.Checked == true)
                {
                    TrStatus = "Available ";
                }

                }
                try
                {
                    
                    Con.Open();
                    string Query = "insert into TRAINTBL values('" + TrNameTb.Text + "'," + TrainCapTb.Text + ",'" + TrStatus + "')";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.ExecuteNonQuery();
                MessageBox.Show("Train added succcessfully");
                    Con.Close();
                populate();
                }
                catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        private void button3_Click(object sender, EventArgs e)
        {
            MainForm Main = new MainForm();
            Main.Show();
            this.Hide(); 
        }
    }

        
    }

