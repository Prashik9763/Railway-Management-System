﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace railway
{
    public partial class cancellation : Form
    {
        public cancellation()
        {
            InitializeComponent();
            populate();
            FillTicket();
        }
        private SqlConnection Con = new SqlConnection(@"Data Source=LENOVO\SQLEXPRESS; Initial Catalog=Railway; Integrated Security=True; Encrypt=True; TrustServerCertificate=True");

        private void populate()
        {
            Con.Open();
            string query = "Select * from CancellationTbl";
            SqlDataAdapter adapter = new SqlDataAdapter(query, Con);
            var ds = new DataSet();
            adapter.Fill(ds);  // Fixed from sda.Fill(ds) to adapter.Fill(ds)
            CancellationDGV.DataSource = ds.Tables[0];
            Con.Close();  // Remember to close your connection
        }

        private void FillTicket()
        {
            // String TrStatus = " Busy";
            Con.Open();
            SqlCommand cmd = new SqlCommand("select Ticketid from ReservationTbl", Con);
            SqlDataReader rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Ticketid", typeof(int));
            dt.Load(rdr);
            TIdCb.ValueMember = "Ticketid";
            TIdCb.DataSource = dt;

            Con.Close(); 
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (TIdCb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Info: ");
                return; // Prevent further execution if information is missing
            }
            else
            {
                try
                {
                    Con.Open();
                    // Ensure column names are exactly as they are in your SQL database
                    string Query = "INSERT INTO CancellationTbl (TickId, CancDate) VALUES (@TickId, @CancDate)";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.Parameters.AddWithValue("@TickId", TIdCb.SelectedValue);
                    cmd.Parameters.AddWithValue("@CancDate", DateTime.Today);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Ticket Cancelled");
                    Con.Close();
                    populate();
                    remove();
                    FillTicket();
                    TIdCb.SelectedIndex = -1; // Reset the selection
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }


        private int CalculateCancldValue()
        {
            // This is a placeholder. You need to implement logic here that determines the value of Cancld.
            return new Random().Next(1000, 9999); // Example: return a random number
        }





        private void remove()
        {
            try
            {
                Con.Open();
                string Query = "DELETE FROM ReservationTbl WHERE TicketId = @TicketId"; // Make sure the column name matches your table
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.Parameters.AddWithValue("@TicketId", TIdCb.SelectedValue);
                cmd.ExecuteNonQuery();

                Con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            MainForm Main = new MainForm();
            Main.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
